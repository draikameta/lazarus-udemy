unit unitClientes;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  ComCtrls, Buttons;

type

  { TFormClientes }

  TFormClientes = class(TForm)
    procedure btSairClick(Sender: TObject);
  private

  public

  end;

var
  FormClientes: TFormClientes;

implementation

{$R *.lfm}

{ TFormClientes }

procedure TFormClientes.btSairClick(Sender: TObject);
begin
    FormClientes.Close;
end;

end.

