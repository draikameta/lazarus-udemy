unit unitDM;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, db, FileUtil, ZConnection, ZDataset;

type

  { TDM }

  TDM = class(TDataModule)
    DataSourceClientes: TDataSource;
    ZConnection1: TZConnection;
    ZQueryClientes: TZQuery;
  private

  public

  end;

var
  DM: TDM;

implementation

{$R *.lfm}

end.

