unit minhas_fucoes;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils,sqldb,ZDataset;

Procedure exibir_clientes(Query:TZQuery);

Procedure incluir_cliente(query:TZQuery;Nome:String;Endereco:String;
  Cidade:String;Estado:String);



implementation

Procedure exibir_clientes(Query:TZQuery);
Begin
   Query.Close;
   Query.SQL.Clear;
   Query.SQL.Add('SELECT * FROM CLIENTE');
   Query.ExecSQL;
   Query.Open;

end;

Procedure incluir_cliente(query:TZQuery;Nome:String;Endereco:String;
  Cidade:String;Estado:String);
begin
  Query.Close;
   Query.SQL.Clear;
   Query.SQL.Add('INSERT INTO CLIENTE(ID,NOME,ENDERECO,CIDADE,ESTADO)');
   Query.SQL.Add(' VALUES(gen_id(id_cliente,1),:NOME,:ENDERECO, ');
   Query.SQL.Add(':CIDADE,:ESTADO) ');

   Query.Params[0].AsString:= Nome;
   Query.Params[1].AsString:= Endereco;
   Query.Params[2].AsString:= Cidade;
   Query.Params[3].AsString:= Estado;


   Query.ExecSQL;
end;


end.

